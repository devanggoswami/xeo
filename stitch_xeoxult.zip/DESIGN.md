---
name: Obsidian Cybernetic
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#1bbd85'
  on-tertiary-container: '#00452e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses high-conviction engineering authority, computational precision, and infrastructural resilience. Designed for enterprise technical founders, cloud architects, and venture infrastructure evaluators, the visual tone eliminates decorative fluff in favor of razor-sharp data density, structured optics, and disciplined futuristic polish.

The aesthetic fuses **Modern Technical Minimalism** with **Controlled Glassmorphism**:
- **Atmosphere:** Deep void environments built on tiered obsidian, charcoal, and midnight slate foundations.
- **Accents:** Electric cyan vector accents coupled with spectral indigo-violet light paths, used sparingly to indicate active telemetry, state changes, and critical compute flows.
- **Credibility & Density:** Metrics are treated as primary architectural artifacts. High-legibility numeric readouts, micro-borders, and disciplined optical alignment communicate enterprise-grade stability and zero-latency performance.

## Colors

The palette is anchored by extreme dark values, reserving luminosity for active computational states and primary action vectors.

- **Background & Canvas:**
  - Base Obsidian: `#0B0F17` (Deepest canvas layer)
  - Surface Raised: `#111827` (Card and panel backgrounds)
  - Surface Border / Division: `#1E293B` (Low-contrast structural delineators)
  - Surface Overlay: `rgba(17, 24, 39, 0.75)` with `12px` backdrop-blur for glass surfaces.

- **Active Accents:**
  - Primary (Cyan Telemetry): `#06B6D4` represents active runtime, focused states, and definitive conversion triggers.
  - Secondary (Deep Violet Compute): `#6366F1` conveys secondary data pathways, synthetic AI logic, and system orchestrations.
  - Tertiary (System Health): `#10B981` indicates cluster health, validated cryptographic proofs, and low-latency nodes.

- **Typography & Monochrome Gradients:**
  - Text Primary: `#F8FAFC` (High dynamic contrast for primary labels and values)
  - Text Secondary: `#94A3B8` (Muted labels, metadata, and inactive parameters)
  - Text Dim: `#475569` (Structural glyphs, disabled contexts, breadcrumb separators)

## Typography

Typography establishes an immediate binary between narrative clarity and machine precision.

- **Plus Jakarta Sans** governs major headings and platform architecture sections. It provides clean, forward-facing geometric authority without appearing playful or consumer-grade.
- **Inter** handles narrative descriptions, table content, form groups, and interactive documentation, chosen for its neutral legibility at sub-pixel scale.
- **JetBrains Mono** is mandatory for telemetry metrics, status pill indicators, hash digests, code snippets, and system coordinates. All uppercase labels must utilize `label-sm` with tabular lining figures (`font-variant-numeric: tabular-nums`).

## Layout & Spacing

The layout model is anchored on an 8pt architectural rhythm, operating over a 12-column responsive fluid grid designed for density without visual friction:

- **Desktop (>= 1280px):** 12 columns, `margin: 2rem` (max-width container clamped at `1440px`), `gutter: 1.5rem`. Enables side-by-side infrastructure logs and visual topology graphs.
- **Tablet (768px - 1279px):** 8 columns, `margin: 1.5rem`, `gutter: 1.25rem`. Dashboards collapse secondary telemetry sidebars into slide-out drawers.
- **Mobile (< 768px):** 4 columns, `margin: 1rem`, `gutter: 1rem`. High-density metric ribbons scroll horizontally with soft edge masking.

Component layouts preserve horizontal alignment along strict bounding boxes to sustain an engineered, cockpit-grade feel.

## Elevation & Depth

Visual hierarchy uses **Glassmorphism backed by Tonal Layering** and **Cyan/Violet Specular Lighting**, avoiding muddy drop-shadows:

- **Surface 0 (Canvas):** `#0B0F17` pure solid ground.
- **Surface 1 (Panels & Shells):** `#111827` base at 80% opacity with `backdrop-filter: blur(16px)` and an outer perimeter rule of `1px solid rgba(30, 41, 59, 0.6)`.
- **Surface 2 (Elevated Nodes & Modals):** `#1E293B` at 70% opacity, `backdrop-filter: blur(24px)`, outlined with `1px solid rgba(6, 182, 212, 0.25)`.
- **Specular Glows:** Critical actions and active nodes cast a soft, diffused glow:
  - Cyan Active: `box-shadow: 0 0 20px -4px rgba(6, 182, 212, 0.35)`
  - Violet Cluster: `box-shadow: 0 0 24px -6px rgba(99, 102, 241, 0.3)`

## Shapes

The design system employs a **Soft (Level 1)** shape radius scale. This preserves the structured, high-precision industrial feel expected in high-performance cloud consoles.

- Standard inputs, buttons, and badges leverage `0.25rem` (`4px`).
- Complex operational cards, cluster topology containers, and dialog shells scale to `rounded-lg` (`0.5rem` / `8px`).
- System-wide status indicator dots and small telemetry markers retain pure circular geometry (`rounded-full`).

## Components

### Buttons
- **Primary:** Solid cyan base (`#06B6D4`), dark text (`#0B0F17`) set in `Plus Jakarta Sans` 600 weight. Slight inner highlight (`inset 0 1px 0 rgba(255, 255, 255, 0.25)`). Hover triggers an electric cyan diffuse glow (`box-shadow: 0 0 16px rgba(6, 182, 212, 0.45)`).
- **Secondary (Ghost Glass):** Transparent background, `1px solid #1E293B`, `#F8FAFC` text. Hover transitions border to `#6366F1` with an ambient violet backwash (`rgba(99, 102, 241, 0.08)`).
- **Destructive:** Surface `rgba(239, 68, 68, 0.1)`, `1px solid rgba(239, 68, 68, 0.4)`, text `#EF4444`.

### Status Badges & Chips
- Formed using `JetBrains Mono` at `label-sm` with uppercase tracking.
- Composed of an ultra-thin border (`1px solid rgba(255, 255, 255, 0.08)`), dark semi-transparent fill (`rgba(17, 24, 39, 0.85)`), and a pulsing pseudo-element LED:
  - **Operational:** `#10B981` beacon with `2px` ping animation.
  - **Compute Active:** `#06B6D4` static beacon with `box-shadow: 0 0 8px #06B6D4`.
  - **Degraded:** `#F59E0B` beacon.

### Cards & Dashboards
- Glassmorphic panels featuring `1px` subtle top-edge gradient strokes simulating overhead lighting (`linear-gradient(to right, rgba(6, 182, 212, 0.4), rgba(99, 102, 241, 0.1), transparent)`).
- Integrated metric headers with single-pixel divider lines in `#1E293B`.

### Form Fields & Inputs
- Monolithic dark fill (`#0B0F17`), inset `1px solid #1E293B`, rounded `4px`.
- Typography set in `Inter` (`body-md`), placeholder in `#475569`.
- **Focus State:** Border shifts sharply to `#06B6D4` paired with an immediate micro-ring (`0 0 0 1px #06B6D4`).

### Checkboxes & Radios
- Square (`4px` radius) and circular elements with an obsidian core and `#1E293B` perimeter.
- Checked state fills with `#06B6D4`, rendering a high-contrast dark `#0B0F17` internal vector check.

### High-Credibility Metric Displays
- Dedicated computational display blocks combining an uppercase micro-label (`label-sm`), massive tabular figures (`Plus Jakarta Sans` or `JetBrains Mono` depending on data tier), and an inline comparative delta chip (e.g., `+99.999% SLA` in `#10B981`).